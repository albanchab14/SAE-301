// scenes/niveau2.js
import * as fct from '../fonctions.js';
import Basescene from "./basescene.js";
import EvilKnight from "../entities/evilknight.js";
import Canon from '../entities/canon.js';
import Gargouille from '../entities/gargouille.js';
import Collectible from '../entities/collectible.js';


export default class Niveau2 extends Basescene {
  constructor() {
    super({ key: "niveau2" });
  }

  preload() {
    this.load.image("Phaser_tuilesdejeu2", "./assets/selectionJeu.png");
    this.load.tilemapTiledJSON("carte2", "./assets/map2.json");
    this.load.image("img_porte_retour", "./assets/door1.png");

    this.load.image("img_canon", "./assets/canon.png");
    this.load.image("balle_canon", "./assets/canonball.png");
    this.load.spritesheet("img_gargouille", "./assets/gargouille.png", { frameWidth: 48, frameHeight: 48 });
    this.load.spritesheet("img_gargouille_vole", "./assets/gargouille_vole.png", { frameWidth: 64, frameHeight: 34 });
    this.load.spritesheet("img_chevalier_mechant", "./assets/chevalier_mechant.png", { frameWidth: 36, frameHeight: 61 });

    this.load.image("img_levier", "./assets/levier.png");
    this.load.image("pont_levis1", "./assets/pont_levis1.png");
    this.load.image("plateforme_mobile1", "./assets/plateforme_mobile1.png");
  }

  create() {
    // Map
    this.map2 = this.add.tilemap("carte2");
    const tileset = this.map2.addTilesetImage("map2_tileset", "Phaser_tuilesdejeu2");
    this.calque_background2 = this.map2.createLayer("calque_background_2", tileset);
    this.calque_background  = this.map2.createLayer("calque_background", tileset);
    this.calque_plateformes = this.map2.createLayer("calque_plateformes", tileset);
    this.calque_echelles    = this.map2.createLayer("calque_echelles", tileset);

    // Collision plateformes
    this.calque_plateformes.setCollisionByProperty({ estSolide: true });
    this.physics.world.setBounds(0, 0, this.map2.widthInPixels, this.map2.heightInPixels);

    // Porte retour
    this.porte_retour = this.physics.add.staticSprite(100, 600, "img_porte_retour");

    // Joueur
    this.player = this.createPlayer(100, 600);
    this.physics.add.collider(this.player, this.calque_plateformes);

    // Caméra
    this.cameras.main.startFollow(this.player);
    this.cameras.main.setBounds(0, 0, this.map2.widthInPixels, this.map2.heightInPixels);

    // vies
    this.events.on('wake', () => { // 1 appel au lancement de scène
      fct.lifeManager.updateHearts(this);
    });
    this.createHearts();
    fct.lifeManager.init(this, this.maxVies);
    
    // --- PLATEFORMES MOBILES ---

    var pont_levis1 = this.physics.add.sprite(782, 650, "pont_levis1");
    this.physics.add.collider(this.player, pont_levis1);
    pont_levis1.body.allowGravity = false;
    pont_levis1.body.immovable = true;

    var plateforme_mobile = this.physics.add.sprite(3040, 904, "plateforme_mobile1");
    this.physics.add.collider(this.player, plateforme_mobile);
    plateforme_mobile.body.allowGravity = false;
    plateforme_mobile.body.immovable = true;
    

    // --- CREATION LEVIERS ---
    this.leversGroup = this.physics.add.staticGroup();

    let lever1 = this.leversGroup.create(310, 222, "img_levier");
    lever1.number = 1;
    lever1.activated = false;
    
    // --- TWEENS ---
    
    // Pont levis
    this.tween_mouvement = this.tweens.add({
      targets: [pont_levis1],
      paused: true,
      ease: "Linear",
      duration: 3000,
      yoyo: false,
      x: "-=160",
      delay: 0,
    });

    // Plateforme mobile
    this.tweens.add({
      targets: [plateforme_mobile],
      paused: false,
      ease: "Linear",
      duration: 3000,
      yoyo: true,
      y: "-=350",
      delay: 0,
      hold: 1000,
      repeatDelay: 1000,
      repeat: -1
    });

    // --- CREATION OBJETS ---
    
    const collectiblesLayer = this.map2.getObjectLayer('collectibles');
    this.collectiblesGroup = Collectible.createFromTilemap(this, collectiblesLayer);
    this.totalFragments = this.collectiblesGroup.getLength();
    
    // Affichage fragments
    if (typeof this.game.config.collectedFragments !== "number") {
      this.game.config.collectedFragments = 0;
    }

    this.createFragmentsText(this.game.config.collectedFragments, 9);
    this.events.on('wake', () => { // 1 appel au lancement de scène
      this.updateFragmentsText(this.game.config.collectedFragments, 9);
    });

    // Fragment collecté
    this.physics.add.overlap(this.player, this.collectiblesGroup, (player, collectible) => {
      collectible.collect();
      this.updateFragmentsText(this.game.config.collectedFragments, 9);
    }, null, this);
      
    
    // --- ENNEMIS ---

    // Animations
    this.anims.create({
      key: 'evilknight_walk_left',
      frames: this.anims.generateFrameNumbers('img_chevalier_mechant', { start: 0, end: 3 }),
      frameRate: 4,
      repeat: -1
    });
    this.anims.create({
      key: 'evilknight_walk_right',
      frames: this.anims.generateFrameNumbers('img_chevalier_mechant', { start: 4, end: 7 }),
      frameRate: 4,
      repeat: -1
    });

    this.anims.create({
      key: "gargouille_idle",
      frames: [{ key: "img_gargouille", frame: 0 }],
      frameRate: 1,
      repeat: -1
    });

    this.anims.create({
      key: "gargouille_fly_left",
      frames: this.anims.generateFrameNumbers("img_gargouille_vole", { start: 0, end: 3 }),
      frameRate: 8,
      repeat: -1
    });

    this.anims.create({
      key: "gargouille_fly_right",
      frames: this.anims.generateFrameNumbers("img_gargouille_vole", { start: 4, end: 7 }),
      frameRate: 8,
      repeat: -1
    });



    this.enemies = this.add.group();
    this.projectiles = this.physics.add.group();

    const ennemis = this.map2.getObjectLayer("ennemis")?.objects || [];
    ennemis.forEach(obj => {
      const dir = obj.properties?.find(p => p.name === "direction")?.value || "droite";
      if (obj.properties?.find(p => p.name === "type")?.value === "evil_knight") {
        this.enemies.add(new EvilKnight(this, obj.x, obj.y, dir));
      }
      if (obj.properties?.find(p => p.name === "type")?.value === "canon") {
        this.enemies.add(new Canon(this, obj.x, obj.y, dir));
      }
      if (obj.properties?.find(p => p.name === "type")?.value === "gargouille") {
        this.enemies.add(new Gargouille(this, obj.x, obj.y, dir));
      }
    });

    this.physics.add.collider(this.enemies, this.calque_plateformes);

    // Collisions joueur ↔ ennemis
    this.physics.add.overlap(this.player, this.enemies, (player, enemy) => {
      const now = this.time.now;
      if (!player.lastHit || now - player.lastHit > 1000) { // 1 seconde d'immunité
        fct.lifeManager.retirerPV(this, 1);
        player.setTint(0xff0000);
        this.time.delayedCall(300, () => player.setTint(0xffffff));
        player.lastHit = now;

        if (this.game.config.pointsDeVie <= 0) {
          this.physics.pause();
          this.game.config.collectedFragments = 0;
          this.game.config.collectedCristals = 0;
          this.bossNameShown = false;
          if (this.miniCristalGreen) {
            this.miniCristalGreen.destroy();
            this.miniCristalGreen = null;
          }
          this.scene.start("defaite");
        }
      }
    });
    
    // Collisions joueur ↔ projectiles
    this.physics.add.overlap(this.player, this.projectiles, (player, projectile) => {
          const now = this.time.now;
          if (!player.lastHit || now - player.lastHit > 1000) {
            fct.lifeManager.retirerPV(this, 1);
            player.setTint(0xff0000);
            this.time.delayedCall(300, () => player.setTint(0xffffff));
            player.lastHit = now;
    
            if (this.game.config.pointsDeVie <= 0) {
              this.physics.pause();
              this.game.config.collectedFragments = 0;
              this.game.config.collectedCristals = 0;
              this.bossNameShown = false;
              if (this.miniCristalGreen) {
                this.miniCristalGreen.destroy();
                this.miniCristalGreen = null;
              }
              this.scene.start("defaite");
            }
            projectile.destroy();
          }
        });
    

    // Clavier
    this.createClavier();

    // A ENLEVER
    this.time.addEvent({
    delay: 10000, // 10 sec en ms
    loop: true,
    callback: () => {
        // Suppose que ton sprite joueur s'appelle this.player
        console.log(`Position joueur : x=${this.player.x}, y=${this.player.y}`);
        // Tu peux aussi le stocker dans un tableau pour tracing ultérieur
        // this.positionsJoueur = this.positionsJoueur || [];
        // this.positionsJoueur.push({ x: this.player.x, y: this.player.y, t: this.time.now });
    }
});
  }

  update() {
    this.updatePlayerMovement();
    this.handleAttack(this.enemies, this.leversGroup);
    this.enemies.children.iterate(enemy => {
      if (enemy instanceof EvilKnight) enemy.update(this.calque_plateformes, this.player);
      if (enemy instanceof Canon) enemy.update(this.player, this.projectiles);
      if (enemy instanceof Gargouille) enemy.update(this.player);
    });

    // Retour
    if (Phaser.Input.Keyboard.JustDown(this.clavier.action) && this.physics.overlap(this.player, this.porte_retour)) {
      console.log("PV restants :", this.game.config.pointsDeVie);
      this.scene.switch("selection");
    }
  }
}