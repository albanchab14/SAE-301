export function attack(player, scene, targets = null) {
    // Hitbox devant le joueur
    const width = 32;             // largeur de l'attaque
    const height = player.height;  // hauteur du joueur

    const dir = player.direction === "gauche" ? -1 : 1;
    const x = player.x + dir * (player.width / 2 + width / 2);
    const y = player.y; // centre vertical du joueur

    // Créer un rectangle invisible pour la hitbox
    const hitbox = scene.add.rectangle(x, y, width, height);
    scene.physics.add.existing(hitbox);
    hitbox.body.setAllowGravity(false);
    hitbox.body.setImmovable(true);

    // Ajuster la position selon la direction
    if (dir === -1) {
    hitbox.x -= width / 2;
    } else {
    hitbox.x += width / 2;
    }


    // Détection collisions avec cibles
    if (targets) {
        scene.physics.add.overlap(hitbox, targets, (h, t) => {
            t.setTint(0xff0000);
            t.destroy(); // ou autre effet
        });
    }

    // La hitbox disparaît après 100 ms
    scene.time.delayedCall(100, () => hitbox.destroy());
}
